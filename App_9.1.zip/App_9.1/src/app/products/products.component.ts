import { Component, OnInit } from '@angular/core';
import { AppConstants } from '../app.constants';
import { DataService } from '../services/data.service';
import { FormsModule } from '@angular/forms'  
import { ReactiveFormsModule} from '@angular/forms' 

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products = [
    {"id":1,"name":"Licensed Frozen Hat","description":"Incidunt et magni","price":"170.00","quantity":56840},
    {"id":2,"name":"Rustic Concrete Chicken","description":"Sint libero mollitia","price":"302.00","quantity":9358},
    {"id":3,"name":"Fantastic Metal Computer","description":"In consequuntur cupiditat","price":"279.00","quantity":90316},
    {"id":4,"name":"Refined Concrete Chair","description":"Saepe nemo praesentium","price":"760.00","quantity":5899}
];
  constructor(private _data : DataService) {
    this.getZIP();
   } 

  getProducerByNo(Email: string, ProducerNumber: string)
  {
    let url = AppConstants.SERVICE_URL + "Producer/GetProducerByNo?Email=" + Email +"&ProducerNumber=" + ProducerNumber
    this._data.GetService(url).subscribe(Producers => { console.log(Producers)});  
  }

  getZIP()
  {
    let url = AppConstants.SERVICE_URL
    this._data.get(url).toPromise().then(response => { console.log(response)});
    // this._data.get(url).toPromise().subscribe(response => { console.log(response)});  
  }

  ngOnInit(): void {
  }
}
