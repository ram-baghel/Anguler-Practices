import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { Observable } from 'rxjs';

//import { AuthService } from './auth.service';

import { HttpClient} from '@angular/common/http';
import { AppConstants } from '../app.constants';

//import {observable, throwError} from 'rxjs'
//import {retry,catchError} from 'rxjs/operators'



@Injectable({
providedIn: 'root'
})

export class AuthInterceptor implements HttpInterceptor {
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = req.clone({
      setHeaders: {
        'Content-Type' : 'application/json; charset=utf-8',
        'Accept'       : 'application/json',
        'Authorization': `Bearer ${AppConstants.yourAccessTokenHere}`,
      },
    });

    return next.handle(req);
  }
}










// @Injectable({
// providedIn: 'root'
// })
export class DataService {

constructor(private http: HttpClient) { }

//used to call GET api's methods
GetService(url: string) {
return this.http.get(url);
}

//used to call POST api's methods
PostService(url: string, toUpdate) {
return this.http.post(url, toUpdate)
}

// createAuthorizationHeader(HttpHeaders: Headers) {
//     HttpHeaders.append('Authorization', 'Basic ' +
//       btoa('username:password')); 
//   }

  get(url) {
    let headers = new Headers();
    // this.createAuthorizationHeader(headers);
    return this.http.get(url, { 
        headers: { 
          'Authorization': 'Bearer' + AppConstants.yourAccessTokenHere,
          'Content-Type' : 'application/json; charset=utf-8',
          'Accept'       : 'application/json',
        }
    });
  }

  post(url, data) {
    let headers = new Headers();
    // this.createAuthorizationHeader(headers);
    return this.http.post(url, data, {
        headers: { 'Authorization': 'Bearer ' + AppConstants.yourAccessTokenHere}
    });
  } 
}



  
