import {HttpHeaders} from "@angular/common/http";
export class AppConstants {
//<--LOCAL(for running API)-->
public static get IntranetSiteURL(): string {return "localhost:4200/"};
public static get SERVICE_URL(): string { return "https://api.trade.gov/gateway/v1/ita_zipcode_to_post/search"};


public static get API_HEADERS(): any {
return new HttpHeaders().set('Content-Type', 'application/json');

};
public static get yourAccessTokenHere():any{
    return '2d337541-c6e0-3482-89ef-6d7fcdb6406f';};
}