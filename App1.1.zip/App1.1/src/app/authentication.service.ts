import { Injectable } from '@angular/core';


interface UserData {
  name: string;
  email: string;
  password: string;
}

@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {
  constructor() { }
  userList = [];
  registerUser(userData: UserData) {
    debugger
    this.userList.push(userData);
    localStorage.setItem('userarray',JSON.stringify(this.userList));
    console.log(this.userList);
  }

  loginUser(userData: UserData) {
    debugger
  const users=JSON.parse(localStorage.getItem('userarray'));
  console.log(JSON.stringify(users));

  users.forEach(user => {
  if(user.email===userData.email && user.password===userData.password)
  {
    alert('Welcome '+user.name);
    console.log(user.name);
    console.log(user.email);
    console.log(user.password);

  }else{
    alert('Authentication Failed.');
  }  
  });
  }
    logOut() {

  }
}
