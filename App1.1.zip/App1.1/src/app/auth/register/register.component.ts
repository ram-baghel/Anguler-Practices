import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AuthenticationService } from 'src/app/authentication.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private auth:AuthenticationService) { }  
 
  ngOnInit(): void {
  }
  register(form) {
    // console.log(form.value);
    console.log(form.value.name);
    console.log(form.value.email);
    console.log(form.value.password);
    this.auth.registerUser(form.value);
  }
}
